$(document).ready(function() {

  $("[id*='pmntmthod']").each(function(){
    $(this).remove();
  });
  
});